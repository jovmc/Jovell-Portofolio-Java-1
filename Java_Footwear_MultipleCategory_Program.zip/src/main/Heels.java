package main;

public class Heels extends Footwear{
	private Double height;
	private String totalWheel;
	
	public Heels(String name, Integer price, Double height, String totalWheel) {
		super(name, price);
		this.height = height;
		this.totalWheel = totalWheel;
		
	}

	public Double getHeight() {
		return height;
	}

	public void setHeight(Double height) {
		this.height = height;
	}

	public String getTotalWheel() {
		return totalWheel;
	}

	public void setTotalWheel(String totalWheel) {
		this.totalWheel = totalWheel;
	}
	
	public void displayDetails() {
	    System.out.printf("Name: %s, Price: %.2f, Height: %.2f\n", getName(), getPrice(), getHeight());
	}

}