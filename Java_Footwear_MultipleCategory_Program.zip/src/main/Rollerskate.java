package main;

public class Rollerskate extends Footwear {
	private Integer totalWheel;
	private String height;
	

	public Rollerskate(String name, Integer price, String height, Integer totalWheel) {
		super(name, price);
		this.totalWheel = totalWheel;
		this.height = height;
	}

	public Integer getTotalWheel() {
		return totalWheel;
	}

	public void setTotalWheel(Integer totalWheel) {
		this.totalWheel = totalWheel;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}
	public void displayDetails() {
	    System.out.printf("Name: %s, Price: %.2f, Total Wheel: %d\n", getName(), getPrice(), getTotalWheel());
	}
}