package main;

import java.util.ArrayList;
import java.util.Scanner;

//Dibuat oleh Jovell (2702243281)
public class Main {
	static Scanner scan = new Scanner (System.in);
	static Integer opsi = 0;
	static ArrayList<Footwear> arrFootwear = new ArrayList<Footwear>();
	
	static public void cls() {
		for (int i = 0; i < 15; i++) {
			System.out.println();
		}
	}
	
	public Main() {
		// TODO Auto-generated constructor stub
		
		do {
			String nameInput;Integer priceInput = 0; String typeInput; Double heightInput = null; Integer wheelInput = null;
			cls();
			System.out.println("Just Du It !!");
			System.out.println("=============");
			System.out.println("1. Add Footwear\n2. View Footwear\n3. Update Footwear\n4. Delete Footwear\n5. Exit");
			do {
				System.out.print(">> ");
				try {
					opsi = scan.nextInt(); scan.nextLine();
				} catch (Exception e) {
					// TODO: handle exception
					scan.nextLine();
				}
			} while (opsi < 1 || opsi > 5);
			
			switch (opsi) {
			case 1:
				do {
					System.out.print("Footwear name [3 - 25 characters]: ");
					nameInput = scan.nextLine();
				} while (nameInput.length()<3 || nameInput.length()>25);
				do {
					System.out.print("Footwear price [more than 10000] : ");
					try {
						priceInput = scan.nextInt(); scan.nextLine();
					} catch (Exception e) {
						// TODO: handle exception
						scan.nextLine();
					}
				} while (priceInput <= 10000);
				do {
					System.out.print("Footwear type [Heels / RollerSkate]: ");
					typeInput = scan.nextLine();
				} while (!typeInput.equals("Heels") && !typeInput.equals("RollerSkate"));
				switch (typeInput) {
				case "Heels":
					do {
						System.out.print("Footwear height [1.0 - 9.0] : ");
						try {
							heightInput = scan.nextDouble(); scan.nextLine();
						} catch (Exception e) {
							// TODO: handle exception
							scan.nextLine();
						}
					} while (heightInput<1.0 || heightInput>9.0);
					//save object ke heels
					String falsewheel = "-";
					arrFootwear.add(new Heels(nameInput, priceInput, heightInput, falsewheel));
					System.out.println("Foot wear added successfully !!");
					break;
				case "RollerSkate":
					do {
						System.out.print("Footwear total wheen [2 - 4 inclusive] : ");
						try {
							wheelInput = scan.nextInt(); scan.nextLine();
						} catch (Exception e) {
							// TODO: handle exception
							scan.nextLine();
						}
					} while (wheelInput<2 || wheelInput>4);
					//save object sebagai roller skate
					String falseheight = "-";
					arrFootwear.add(new Rollerskate(nameInput, priceInput, falseheight, wheelInput));

					System.out.println("Foot wear added successfully !!");
					break;
				}
				break;
			case 2:
				if (arrFootwear.isEmpty()) {
					System.out.println("There are no footwears to display !");
				} else {
					displayFootwearTable(); 
				}
				break;
			case 3:
				Integer updateIndex = 0; String updateName = ""; Integer updatePrice = 0; Double updateHeight = 0.0; Integer updateWheel = 0;
				if (arrFootwear.isEmpty()) {
					System.out.println("There are no footwears to display !");
				} else {
					displayFootwearTable(); 
					do {
						System.out.print("Input footwear index to update : ");
						try {
							updateIndex = scan.nextInt(); scan.nextLine();
						} catch (Exception e) {
							// TODO: handle exception
							scan.nextLine();
						}
					} while (updateIndex<1 || updateIndex>arrFootwear.size());
					
					// Untuk update footwear sesuai indeks
					Footwear updateFootwear = arrFootwear.get(updateIndex - 1);
					
					do {
						System.out.print("Footwear name [3 - 25 characters]: ");
						updateName = scan.nextLine();
					} while (updateName.length()<3 || updateName.length()>25);
					
					do {
						System.out.print("Footwear price [more than 10000] : ");
						try {
							updatePrice = scan.nextInt(); scan.nextLine();
						} catch (Exception e) {
							// TODO: handle exception
							scan.nextLine();
						}
					} while (updatePrice <= 10000);
					
					if (updateFootwear instanceof Heels) {
						do {
							System.out.print("Footwear height [1.0 - 9.0] : ");
							try {
								updateHeight = scan.nextDouble(); scan.nextLine();
							} catch (Exception e) {
								// TODO: handle exception
								scan.nextLine();
							}
						} while (updateHeight<1.0 || updateHeight>9.0);
						Heels updateHeels = new Heels(updateName, updatePrice, updateHeight, "-");
						arrFootwear.set(updateIndex - 1, updateHeels);
						
					} else if (updateFootwear instanceof Rollerskate) {
						do {
							System.out.print("Footwear total wheel [2 - 4 inclusive] : ");
							try {
								updateWheel = scan.nextInt(); scan.nextLine();
							} catch (Exception e) {
								// TODO: handle exception
								scan.nextLine();
							}
						} while (updateWheel<2 || updateWheel>4);
						Rollerskate updateRollerskate = new Rollerskate(updateName, updatePrice, "-", updateWheel);
						arrFootwear.set(updateIndex - 1, updateRollerskate);
					}
					System.out.println("Footwear updated successfully !!");
				}
				break;
			case 4:
				Integer deleteInput = 0;
				if (arrFootwear.isEmpty()) {
					System.out.println("There are no footwears to display !");
				} else {
					displayFootwearTable();
					do {
						System.out.print("Input footwear index to delete : ");
						try {
							deleteInput = scan.nextInt(); scan.nextLine();
						} catch (Exception e) {
							// TODO: handle exception
							scan.nextLine();
						}
					} while (deleteInput<1 || deleteInput>arrFootwear.size() + 1);
					arrFootwear.remove(deleteInput-1);
					System.out.println("Footwear deleted successfully !!");
				}
				break;
			default:
				break;
			}
		} while (opsi!=5);
	
		System.out.println("Thanks for using Just DU It Program !");
	}
	public void displayFootwearTable() {
		for (int i = 0; i < 70; i++) {
			System.out.print("=");
		}
		System.out.println();
	    System.out.printf("| %-3s | %-25s | %-8s | %-7s | %-11s |\n", "No", "Name", "Price", "Height", "Total Wheel");
	    for (int i = 0; i < 70; i++) {
			System.out.print("=");
		}
	    System.out.println();
	    
	    for (int i = 0; i < arrFootwear.size(); i++) {
	        Footwear footwear = arrFootwear.get(i);
	        String name = footwear.getName();
	        Integer price = footwear.getPrice();
	        String height = (footwear instanceof Heels) ? ((Heels) footwear).getHeight() + " cm" : "-";
	        //Contoh tidak menggunakan ternary
//	        String height;
//	        if (footwear instanceof Heels) {
//	            height = ((Heels) footwear).getHeight() + " cm";
//	        } else {
//	            height = "-";
//	        }
	        String totalWheel = (footwear instanceof Rollerskate) ? ((Rollerskate) footwear).getTotalWheel() + " Wheels" : "-";

	        System.out.printf("| %-3d | %-25s | %-8d | %-7s | %-11s |\n", 
	                          i + 1, name, price, height, totalWheel);
	    }
	    for (int i = 0; i < 70; i++) {
			System.out.print("=");
		}
	    System.out.println();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}